# Built at Fri Feb 17 10:57:13 UTC 2023
import sys

print("Running Backend...")
print("Python version is: " + sys.version)

sys.exit(0)

